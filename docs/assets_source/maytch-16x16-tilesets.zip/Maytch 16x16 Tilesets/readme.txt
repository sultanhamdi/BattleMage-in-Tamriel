Tiles produced during Ludum Dare 42 by Maytch. 

Animated sprites/tiles are named by their sprite size and number of frames.

Free to use in your games, free to edit. Credit would be nice but not required if tiles make it into production. If you make something cool message me on twitter @Maytch as it'd be awesome to see.

